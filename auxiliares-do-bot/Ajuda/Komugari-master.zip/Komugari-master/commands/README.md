<html>
  <header>
    <a href = 'https://discordapp.com/oauth2/authorize?client_id=365907645795794946&scope=bot&permissions=1043721303'>
      <img align="right" src="https://a.safe.moe/hu4ry.png" height="400">
    </a>

<h1> Komugari <a href = 'https://discordapp.com/oauth2/authorize?client_id=365907645795794946&scope=bot&permissions=1043721303'>
  <img src="https://a.safe.moe/4kKNg.png" height="25">
</a></h1>

### Your Friendly Neighbourhood Submarine Bringing you the Best Lewds™

[![Fuck it Ship it](http://forthebadge.com/images/badges/fuck-it-ship-it.svg)](https://mitorisia.github.io/Komugari/)[![Kinda SFW](http://forthebadge.com/images/badges/kinda-sfw.svg)](https://mitorisia.github.io/Komugari/)[![Made with Crayons](http://forthebadge.com/images/badges/made-with-crayons.svg)](https://mitorisia.github.io/Komugari/)

# Index

- [General](#General)
- [Info](#Info)
- [Utility](#Utility)
- [Fun](#Fun)
- [Memes](#Memes)
- [Moe-Deration](#Moe-Deration)
- [Music](#Music)
- [Anime](#Anime)
- [Action](#Action)
- [NSFW](#NSFW)

## Legend
Name | Description 
----------------|--------------
`[]` | Indicates a mandatory argument, you must provide this for the command to work!
`<>` | Indicates an optional argument, you do not need to provide this for the command to work


## General (12)
Name | Description | Usage
----------------|--------------|-------
`Help` | Sends the generic help message! | `~help`
`Commands` | Displays a list of current commands! | `~commands`
`Extras` | Displays a list of extra commands! | `~extras`
`Nsfwcommands` | Displays a list of NSFW commands! | `~nsfwcommands`
`Botinfo` | Sends the current info on Komugari! | `~botinfo`
`Invite` | Gives you the invite link! | `~invite`
`Uptime` | Tells you how long the bot has been running consecutively! | `~uptime`
`Ping` | Pings the bot, giving you the latency in milliseconds! | `~ping`
`Support` | Ask support a message! Maybe they'll respond..who knows? | `~support [message]`
`Howto` | How...do I make this channel...NSFW? Wonder no more! | `~howto`
`Nomore` | There's too much NSFW! How do I change it back? Komu's got your back! | `~nomore`
`Iku` | Sends a picture of the best girl! I-19! | `~iku`

###### [Back to ToC](#contents)

## Info (9)
Name | Description | Usage
----------------|--------------|-------
`User` | Gets information on a user! | `~user <user>`
`Avatar` | Retrieves the user's avatar! | `~avatar <user>`
`Channel` | Displays information on the specified channel! If none provided, all channels will be listed with corresponding permissions for the user that triggered the command! | `~channel <channel>`
`Server` | Displays information on the server! | `~server`
`Role` | Displays information on the specified role! If none provided, all roles will be listed! | `~role <role>`
`Inrole` | Finds all the users in the specified role! If none provided, all members will be listed! | `~inrole [role]`
`Edits` | Grabs a message's recent edits! | `~edits [message ID]`
`Discrim` | Finds all the users that have the corresponding discriminator! | `~discrim <4 digit number>`
`Emoji` | Enlarges the specified emoji! Or lists all the custom emojis! | `~emoji <custom emoji>`

###### [Back to ToC](#contents)

## Utility
Name | Description | Usage
----------------|--------------|-------
`Color` | Shows you a preview of a color or a random color! | `~color <hex code>`
`GitHub` | Searches for repositories on GitHub and retrieves their information! | `~github <(user/repo) | (search)>`
`Img` | Searches google images for your tags! | `~img [tags]`
`Jisho` | Searches Jisho.org for your term! | `~jisho [term]`
`Math` | Evaluates a math equation! | `~math [equation]`
`Osu` | Searches osu! for a user! | `~osu [user]`
`Remindme` | DMs you with the reminder after a specified amount of time! Is not the most accurate, so keep it short! | `~remindme [event] [time]`
`Temperature` | Converts temperature between Celsius, Fahrenheit, and Kelvin | `~temperature [base] [to] [amount]`
`Time` | Fetches the time in the specified location! | `~time [location]`
`Translate` | Translates the given text into the desired language! | `~translate [language] [text]`
`Urban` | Searches for a word on Urban Dictionary! If none provided, a random definition will be provided! | `~urban [word]`
`Weather` | Finds the weather in the specified  | `~weather [location]`
`Wiki` | Searches WikiPedia for your term! | `~wiki [term]`
`YouTube` | Searches youtube for a matching video! | `~youtube [tags]`

###### [Back to ToC](#contents)

## Fun
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

## Memes
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

## Moe-Deration
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

## Anime
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

## Action
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

## NSFW
[![Ages 18](http://forthebadge.com/images/badges/ages-18.svg)](https://mitorisia.github.io/Komugari/)
Name | Description | Usage
----------------|--------------|-------
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``
`` |  | ``

###### [Back to ToC](#contents)

#### Haha Thanks for Reading all of This LmmFaO